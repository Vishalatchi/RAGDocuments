import asyncio
import logging
import sys
import uuid
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient

FALLBACK_REQUEST_ID = uuid.uuid5(uuid.NAMESPACE_URL, "Request").hex[:12]


@pytest.fixture
def main(monkeypatch):
    monkeypatch.setattr("qdrant_client.QdrantClient", MagicMock())
    monkeypatch.setattr("ollama.Client", MagicMock())
    monkeypatch.setattr("langchain_ollama.OllamaEmbeddings", MagicMock())
    monkeypatch.setattr("fastembed.SparseTextEmbedding", MagicMock())
    sys.modules.pop("src.rag_app.ingestion.pipeline", None)
    sys.modules.pop("api.routes.ingestion", None)
    sys.modules.pop("api.main", None)
    from api import main as main_mod

    return main_mod


@pytest.fixture
def client(main):
    return TestClient(main.app)


def test_app_title_and_registered_routes(main):
    paths = set(main.app.openapi()["paths"])

    assert main.app.title == "RAG system"
    assert "/" in paths
    assert "/ingestion/create_collection" in paths
    assert "/ingestion/load_files" in paths
    assert "/ingestion/delete_files" in paths
    assert "/ragapi/generate_answer" in paths


def test_root_returns_running_message(client):
    response = client.get("/")

    assert response.status_code == 200
    assert response.json() == {"message": "app is running"}


def test_middleware_logs_supplied_request_id(client, main, caplog):
    caplog.set_level(logging.INFO, logger="api.main")

    response = client.get("/", headers={"X-Request-ID": "req-123"})

    assert response.status_code == 200
    messages = [record.message for record in caplog.records if record.name == "api.main"]
    assert any(
        message.startswith("Request startedRequest ID: req-123 - GET ")
        and message.endswith("/")
        for message in messages
    )
    assert any(
        "Request completed. ID: req-123 - response status code : 200 Time taken:" in message
        and message.endswith(" ms")
        for message in messages
    )
    assert main.request_id_var.get() == "-"


def test_middleware_uses_fixed_fallback_id_when_header_is_absent(client, caplog):
    caplog.set_level(logging.INFO, logger="api.main")

    response = client.get("/")

    assert response.status_code == 200
    assert any(
        f"Request startedRequest ID: {FALLBACK_REQUEST_ID} - GET " in record.message
        for record in caplog.records
        if record.name == "api.main"
    )


def test_middleware_uses_fallback_id_when_header_is_empty(client, caplog):
    caplog.set_level(logging.INFO, logger="api.main")

    response = client.get("/", headers={"X-Request-ID": ""})

    assert response.status_code == 200
    assert any(
        f"Request startedRequest ID: {FALLBACK_REQUEST_ID} - GET " in record.message
        for record in caplog.records
        if record.name == "api.main"
    )


def test_middleware_returns_response_from_call_next(main):
    request = MagicMock()
    request.headers.get.return_value = "req-direct"
    request.method = "POST"
    request.url = "http://test/direct"
    response = MagicMock()
    response.status_code = 201

    async def call_next(received):
        assert received is request
        return response

    result = asyncio.run(main.log_request(request, call_next))

    assert result is response
    assert main.request_id_var.get() == "-"


def test_middleware_raises_when_call_next_fails_before_response_exists(main, caplog):
    caplog.set_level(logging.INFO, logger="api.main")
    request = MagicMock()
    request.headers.get.return_value = "req-crash"
    request.method = "GET"
    request.url = "http://test/crash"

    async def call_next(received):
        raise RuntimeError("route failed")

    with pytest.raises(UnboundLocalError):
        asyncio.run(main.log_request(request, call_next))

    messages = [record.message for record in caplog.records if record.name == "api.main"]
    assert any("Request startedRequest ID: req-crash - GET http://test/crash" == message for message in messages)
    assert all("Request crashed" not in message for message in messages)
    assert main.request_id_var.get() == "-"
